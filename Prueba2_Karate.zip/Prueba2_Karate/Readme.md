#Pruebas de Registro e Inicio de Sesión en DemoBlaze

Este repositorio contiene pruebas automatizadas utilizando Karate para el registro e inicio de sesión en la aplicación DemoBlaze.

Estructura del Código:
- Feature: Pruebas de registro y inicio de sesión en DemoBlaze: Define los escenarios de prueba para el registro e inicio de sesión.
- Background: Configura la URL base para las peticiones a la API de DemoBlaze.
- Escenarios:
    1. Crear un nuevo usuario en signup: Prueba la funcionalidad de registro con un nuevo usuario.
    2. Intentar crear un usuario ya existente: Prueba la restricción de registro con un usuario que ya existe.
    3. Usuario y contraseña correctos en login: Verifica que el inicio de sesión sea exitoso con credenciales válidas.
    4. Usuario y contraseña incorrectos en login: Prueba el manejo de errores al ingresar credenciales incorrectas.

Instrucciones de Uso:
1. Asegúrate de tener instalado Karate en tu entorno.
2. Clona este repositorio en tu máquina local.
3. Ejecuta las pruebas automatizadas utilizando Karate.
4. Ejecuta el feature "demoblaze.feature"