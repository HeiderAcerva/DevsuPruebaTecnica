
require('cypress-plugin-tab')
class PurchasePage {
    fillForm() {
      cy.get('#name').type("HEIDER").tab()
      .type("Colombia").tab()
      .type("Bogotá").tab()
      .type("4123456789").tab()
      .type("abril").tab()
      .type("2024")
    }
  
    completePurchase() {
      cy.contains('Purchase').click();
    }
  
    elementExists(selector) {
      return cy.get('body').then(body => {
        return body.find(selector).length > 0;
      });
    }
    
    validatePurchase() {
      cy.contains('Thank you for your purchase!').then((element) => {
        if (element.is(':visible')) {
          cy.screenshot();
        } else {
          throw new Error('Thank you message not visible.');
        }
      });
    }
  }
  
  export default PurchasePage;
  //
  